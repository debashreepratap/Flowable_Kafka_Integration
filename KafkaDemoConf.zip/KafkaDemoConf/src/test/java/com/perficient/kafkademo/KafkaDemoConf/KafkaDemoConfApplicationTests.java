package com.perficient.kafkademo.KafkaDemoConf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaDemoConfApplicationTests {

	@Test
	void contextLoads() {
	}

}
