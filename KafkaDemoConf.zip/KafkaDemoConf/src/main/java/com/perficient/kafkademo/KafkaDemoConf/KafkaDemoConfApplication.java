package com.perficient.kafkademo.KafkaDemoConf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaDemoConfApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaDemoConfApplication.class, args);
	}

}
